What this folder contains:
This folder contains 4 sets of position textures 1st to 10th. Each set has two subfolders 'With Arrow Down' and 'Without Arrow Down'.
E.g. the 'With Arrow Down' textures might be shown above a car with the arrow pointing down to the car, whereas the 'Without Arrow Down' textures might appear as a UI Image.
This folder also contains a folder called 'Older (from v1)' which contains some Position Textures used in an earlier version of the Race Positioning System

How we created them:
We used Microsoft Office Powerpoint 2007 to create all of the textures you will find in the folder.
We have included the PowerPoint file called 'PositionTextures.ppt' which contains the position textures as wordart which can be edited to create as many as you need.
We have included one of each type, both with and without arrows.
If you right click on the wordart in PowerPoint you can click 'Save as Picture' to save it a .png which you can import and use in Unity.